<?php
require 'database.php';

print_r($_POST['estado']);
               
$comentario = $_POST['comentario'];
              
$id= $_POST['id'];

$estado= $_POST['estado'];

$nombre=$_POST['nombre'];


                   







$sql = $conn->prepare("UPDATE turno SET estado = '$estado',comentario_procesa = '$comentario' , fecha_atendido= NOW() WHERE turno_id = '$id ' ");

$sql->execute();



    if($sql)
    {
        print_r('succesfully');
       header("location: Tabla-Turnos.php");

}else{
    
    echo "Insercion no exitosa";
    }
  