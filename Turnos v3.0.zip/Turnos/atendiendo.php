<?php

require 'database.php';
require 'PHPMailer.php';
require 'SMTP.php';
require 'Exception.php';
require 'OAuth.php';

 session_start();
print_r($_SESSION['user_id']);
$administrador= $_SESSION['user_id'];
if(!isset($_SESSION['user_id'])) 
    {
       header("Location:/Turnos/login.php"); 
    }

echo $id = $_GET["val"];

$sql = $conn->prepare("UPDATE turno SET fecha_atendiendo=now(),email_adm= '$administrador',estado = 'atendiendo' where turno_id = '$id' ");


    
if($sql->execute())
{
    
    
$vista= $conn->prepare("select * from turno natural join visitante where turno_id ='$id' ");
                    $vista->execute();
                    $lista= $vista->fetch(PDO::FETCH_ASSOC);
                   print_r($lista);

     
    
    $destinatario= $lista['email_visitante'];
    $nombre =$lista['nombre'];
    $apellido= $lista['apellido'];
      $mail = new PHPMailer\PHPMailer\PHPMailer();

$mail->isSMTP();

$mail->SMTDebug = 0;
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = "sistema.de.turnos.upra@gmail.com";
$mail->Password = "Turnos1234";
$mail->setFrom('sistema.de.turnos.upra@gmail.com', 'Sistema de Turnos Admiciones');
$mail->addAddress($destinatario,'Visitante');
$mail->Subject = 'Notificacion de turno';
$mail->Body = $nombre;
$mail->Body .=" ";
$mail->Body .=$apellido;
$mail->Body .= " es su turno, favor de pasar por la oficina de admisiones.";
   






$mail->IsHTML(true);

if($mail->send()){
    
    $records = $conn->prepare("SELECT COUNT(turno_id) FROM turno WHERE estado = 'esperandoturno'");
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);
           $losesperando = $results['COUNT(turno_id)'];
    print_r($losesperando);
    
    echo "notificacion enviada";
    
    if($losesperando>1)
    {
        $records8 = $conn->prepare("SELECT min(visitante_id) FROM `turno` WHERE fecha_atendiendo is null");
    $records8->execute();
    $results8 = $records8->fetch(PDO::FETCH_ASSOC);
       
        $destinatario2= $results8['min(visitante_id)'];
   
    print_r($destinatario2);
        
        $records9 = $conn->prepare("SELECT * ,min(visitante_id) FROM `turno` natural join visitante WHERE fecha_atendiendo is null and visitante_id > '$destinatario2'");
             $records9->execute();
        $results9 = $records9->fetch(PDO::FETCH_ASSOC);
        $destinatario5 = $results9['email_visitante'];
        
        $nombre1 =$results9['nombre'];
    $apellido1= $results9['apellido'];
         print_r($destinatario5);
        
         $mail = new PHPMailer\PHPMailer\PHPMailer();

$mail->isSMTP();

$mail->SMTDebug = 0;
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = "sistema.de.turnos.upra@gmail.com";
$mail->Password = "Turnos1234";
$mail->setFrom('sistema.de.turnos.upra@gmail.com', 'Sistema de Turnos Admiciones');
$mail->addAddress($destinatario5,'Visitante');
$mail->Subject = 'Notificacion de turno';
$mail->Body = $nombre1;
$mail->Body .=" ";
$mail->Body .=$apellido1;
$mail->Body .= " quedan 2 turnos antes del suyo, favor de acercarse por la oficina de admisiones.";
   






$mail->IsHTML(true);

if($mail->send()){
}
        
        
         echo "mensaje enviado al el desdes del despues";
        
        
        
        
        
        
        
        
        
        
    }
    
}
else{
    echo "mensaje no enviado";
    
}
      
    
    
}


?>




<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">



    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main2.css" rel="stylesheet" media="all">

<!--
    <script type="text/javascript">
    function CheckServicio(val){
     var element=document.getElementById('servicio');
     if(val=='Opciones'||val=='otros')
       element.style.display='block';
     else
       element.style.display='none';
    }

    </script>
-->

</head>
    

<body>


    <div class="page-wrapper bg-gra-03 p-t-45 p-b-50">
        <div class="wrapper wrapper--w790">
            <div class="card card-5">
                <div class="card-heading">
                    <h2 class="title">Atendiendo al Visitante </h2>
                </div>
                <div class="card-body">
                    
                    <form action="atendidoProceso.php"  method="POST">
                        <div class="form-row m-b-55">
                            <div class="name">Nombre</div>
                            
                            <div class="value">
                                <div class="row row-space">
                                    <div class="col-2">
                                        <div class="input-group-desc">
                                            
                                            <input name="nombre" value="<?php echo $lista['nombre']; ?>" class="input--style-5" readonly  >
                                            
                                            <label class="label--desc">Nombre</label>
                                        </div>
                                    </div>
                                    <div class="col-2"><div class="input-group-desc"  >
                                            <input name="apellido" value="<?php echo $lista['apellido']; ?>" class="input--style-5" readonly >
                                            <label class="label--desc">Apellido</label>
                                            
                                            
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                            <div class="value">
                                <div class="input-group">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Email</div>
                            <div class="value">
                                <div class="input-group">
                                            <input name="email_visitante" value="<?php echo $lista['email_visitante']; ?>" class="input--style-5" readonly >
                                    <label class="label--desc">Email</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Turno</div>
                            <div class="value">
                                <div class="input-group">
                                            <input  name="id" value="<?php echo $lista['turno_id']; ?>" class="input--style-5" readonly >
                                    <label class="label--desc">ID</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Número de Teléfono</div>
                            <div class="value">
                                <div class="input-group">
                                            <input name="numero_telefono" value="<?php echo $lista['numero_telefono']; ?>" class="input--style-5" readonly >
                                    <label class="label--desc">Número de Teléfono</label>
                                </div>
                            </div>
                        </div>

                        <!--<div class="form-row">
                            <div class="name">Tipo de Estudiante</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                        <select name="subject">
                                            <option disabled="disabled" selected="selected">Opciones</option>
                                            <option>Estudiante de Nuevo Ingreso</option>
                                            <option>Estudiante de Transferencia</option>

                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>

                            </div>
                        </div>-->

                          <div class="form-row">
                              <div class="name">Servicio</div>
                              <div class="value">
                                  <div class="input-group">
                                            <input name="tipo_servicio" value="<?php echo $lista['tipo_servicio']; ?>" class="input--style-5" readonly >
                                      <label class="label--desc">Servicio</label>
                                  </div>
                              </div>
                          </div>

                          <div class="form-row">
                              <div class="name">Estado</div>
                              <div class="value">
                                  <div class="input-group">
                                      <div class="rs-select2 js-select-simple select--no-search">
                                          
                                          <select name="estado">
                                              <option disabled="disabled" selected="selected">Opciones</option>
                                              <option value="Completado">Completado</option>
                                              <option value="No Completado">No Completado</option>
                                          </select>
                                          
                                          <div class="select-dropdown"></div>
                                      </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="name">Comentario</div>
                                <div class="value">
                                    <div class="input-group">
                                        <input name= "comentario"class="input--style-5" type="comentario" Comentario="comentario">
                                        <label class="label--desc">Comentario</label>
                                    </div>
                                </div>
                            </div>


                        <div>
                            
                            
                            
                             <input class="btn btn--radius-2 btn--red" type="submit" value="Atendido">
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->
