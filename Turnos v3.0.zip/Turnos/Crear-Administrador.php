<?php

require 'database.php';
session_start();

if(!isset($_SESSION['user_id'])) 
    {
       header("Location:/Turnos/login.php"); 
    }
if($_SESSION['tipo']==2)
    {
        
       header("Location:/Turnos/logout.php"); 
    }
print_r($_SESSION['user_id']);
$administrador= $_SESSION['user_id'];
 print_r($_POST['tipo_admin']);


  if (!empty($_POST['email_adm']) && !empty($_POST['contrasena'])&&!empty($_POST['tipo_admin'])  )  
  {
    $sql = "INSERT INTO administrador (email_adm, contrasena,tipo_admin,activo_admin) VALUES (:email_adm,:contrasena,:tipo_admin,'1')";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email_adm', $_POST['email_adm']);
    $stmt->bindParam(':contrasena', $_POST['contrasena']);
    $stmt->bindParam(':tipo_admin', $_POST['tipo_admin']);
    
    
      
  
   
      
      

      
  if ($stmt->execute()) 
  {
     
    
     if (!empty($_POST['email_adm']) &&empty($_POST['comentario'])  )  
  {

     
     
     $sql2 = "INSERT INTO editado (email_adm, email_adm_editado,fecha_editado,operacion) VALUES ('$administrador',:email_adm_editado,NOW(),'creado')";
    $stmt2 = $conn->prepare($sql2);
      
       $stmt2->bindParam(':email_adm_editado', $_POST['email_adm']);
       

     
    

     
     if ($stmt2->execute()) 
  {
     
    
      
      echo $message1 = 'Successfully created new user';
      
      header("location:/Turnos/manejaradministrador.php"); 
      
    } else {
      echo $message1 = 'Sorry there must have been an issue creating your account';
    }
     
  }
      if (!empty($_POST['email_adm']) &&!empty($_POST['comentario'])  )  
  {

     
     
     $sql2 = "INSERT INTO editado (email_adm, email_adm_editado,fecha_editado,operacion,comentario_editado) VALUES ('$administrador',:email_adm_editado,NOW(),'creado',:comentario)";
    $stmt2 = $conn->prepare($sql2);
      
       $stmt2->bindParam(':email_adm_editado', $_POST['email_adm']);
        $stmt2->bindParam(':comentario', $_POST['comentario']);

     
    

     
     if ($stmt2->execute()) 
  {
     
    
      
     echo $message1 = 'Successfully created new user';
      
      header("location:/Turnos/manejaradministrador.php"); 
      
    } else {
      echo$message1 = 'Sorry there must have been an issue creating your account';
    }
     
  }

      echo $message1 = 'Successfully created new user';
      
      //header("location:/Turnos/manejaradministrador.php"); 
      
    } 
      
      
      else {
      echo $message1 = 'Su credencial de EMAIL ya existe no se pudo crear';
    }
  }





  /*   if (!empty($_POST['email_adm']) &&empty($_POST['comentario'])  )  
  {

     
     
     $sql2 = "INSERT INTO editado (email_adm, email_adm_editado,fecha_editado,operacion) VALUES ('$administrador',:email_adm_editado,NOW(),'creado')";
    $stmt2 = $conn->prepare($sql2);
      
       $stmt2->bindParam(':email_adm_editado', $_POST['email_adm']);
       

     
    

     
     if ($stmt2->execute()) 
  {
     
    
      
      $message1 = 'Successfully created new user';
      
      header("location:/Turnos/manejaradministrador.php"); 
      
    } else {
      $message1 = 'Sorry there must have been an issue creating your account';
    }
     
  }*/
    
      



 /*if (!empty($_POST['email_adm']) &&!empty($_POST['comentario'])  )  
  {

     
     
     $sql2 = "INSERT INTO editado (email_adm, email_adm_editado,fecha_editado,operacion,comentario_editado) VALUES ('$administrador',:email_adm_editado,NOW(),'creado',:comentario)";
    $stmt2 = $conn->prepare($sql2);
      
       $stmt2->bindParam(':email_adm_editado', $_POST['email_adm']);
        $stmt2->bindParam(':comentario', $_POST['comentario']);

     
    

     
     if ($stmt2->execute()) 
  {
     
    
      
      $message1 = 'Successfully created new user';
      
      header("location:/Turnos/manejaradministrador.php"); 
      
    } else {
      $message1 = 'Sorry there must have been an issue creating your account';
    }
     
  }

     
     */
     

?>











<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Crear Administrador</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/login-form---Ambrodu-1.css">
    <link rel="stylesheet" href="assets/css/login-form---Ambrodu.css">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body id="page-top">
    <div id="wrapper">
        <nav class="navbar navbar-dark align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0">
            <div class="container-fluid d-flex flex-column p-0">
                <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="">
                    <div class="sidebar-brand-icon rotate-n-15"></div>
                    <div class="sidebar-brand-text mx-3"><span>admin panel</span></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="nav navbar-nav text-light" id="accordionSidebar">
                   <li class="nav-item" role="presentation">
                        <a class="nav-link active" href="index.php"><i class="fas fa-home"></i><span>Inicio</span></a>
                        <a class="nav-link active" href="reportes.php"><i class="fas fa-users-cog"></i><span>Reportes</span></a>
                        <a class="nav-link active" href="Tabla-Turnos.php"><i class="fas fa-table"></i><span>Tabla de Turnos</span></a>
                        <?php if($_SESSION['tipo']==1) { ?>
                        <a class="nav-link active"
                            href="Crear-Administrador.php"><i class="fas fa-user-plus"></i><span>Crear Administrador</span></a>
                        <a class="nav-link active" href="manejaradministrador.php">
                        <i class="fas fa-user-times"></i><span>Manejar Administrador</span></a>
                         <?php }?>
                        <a class="nav-link active" href="logout.php">
                        <i class="fa fa-sign-out" style="font-size:18px" ></i><span>Logout</span></a>
                        
                            
                    </li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                          <h5>Bienvenido: <?php echo $_SESSION['user_id']?></h5>
                    <div class="container-fluid"><button class="btn btn-link d-md-none rounded-circle mr-3" id="sidebarToggleTop" type="button"><i class="fas fa-bars"></i></button></div>
                </nav>
                <div class="container-fluid">
                    <div class="d-sm-flex justify-content-between align-items-center mb-4"></div>
                </div>
                <div class="body" style="padding-top: 50px;">
                    <div class="border rounded shadow login-center">
                        
                        <form action="Crear-Administrador.php"  method="post" style="padding-top: 32px;">
                            <div class="form-group text-center"><img class="img-fluid" style="width: 300px;" src="assets/img/default.png"></div>
                            
                            
                            <div class="form-group d-flex justify-content-center">
                                
                                <input  required class="form-control" type="email" style="width: 300px;" placeholder="Email" name="email_adm"></div>
                            
                            
                            <div required class="form-group d-flex justify-content-center">
                                
                                <input class="form-control" type="password" style="width: 300px;" placeholder="Contraseña" name="contrasena">
                            
                            </div>
                            
                              <div class="form-group d-flex justify-content-center">
                                
                                <input class="form-control" type="text" style="width: 300px;" placeholder="Escriba un comentario" name="comentario"
                                       name="comentario">
                            
                            </div>



                            <div required class="dropdown form-group d-flex justify-content-center">

                                <select name="tipo_admin" required >
                                    <option value="">Tipo de Administrador </option>
                                   <option value="2">Administrador </option>
                                    <option value="1">Super Administrador</option>
                                 

                                </select>
                                <div class="select-dropdown"></div>
                            </div>




        <!--                    <div class="  dropdown form-group d-flex justify-content-center  ">
                            <button class=" btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Tipo de Usuario
                            </button>
                            <div class="dropdown-menu  w-25 p-3 " aria-labelledby="dropdownMenuButton">
                              <a class="dropdown-item " href="#">Administrador</a>
                              <a class="dropdown-item" href="#">Empleado</a>
                            </div>
                          </div>
-->

                            <div class="form-group d-flex justify-content-center">
                                
                                
                              <input class="btn btn-dark" type="submit" value="Crear Administrador">

                            
                            </div>
                            
                           

                        </form>
                    </div>
                </div>
            </div>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/theme.js"></script>
</body>

</html>
