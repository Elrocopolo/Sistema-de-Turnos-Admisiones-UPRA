
<?php

  session_start();

if (isset($_SESSION['user_id'])) 
 {
    header('Location:/Turnos/index.php');
}

  require 'database.php';

  if (!empty($_POST['email_adm']) && !empty($_POST['contrasena'])) 
  {
    $records = $conn->prepare('SELECT * FROM administrador WHERE email_adm = :email_adm');
    $records->bindParam(':email_adm', $_POST['email_adm']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);
    $message = '';
    
      
      if (count($results) > 0 && $_POST['contrasena']== $results['contrasena']) 
  {
          if($results['activo_admin']==1 ){
        
              $_SESSION['user_id'] = $results['email_adm'];
              $_SESSION['tipo'] = $results['tipo_admin'];
              
                header("Location: /Turnos/index.php");

          }
            else{
                      $message = 'Lo sentimos los credenciales estan correctos pero su cuenta esta desactivada ';

            }
    } 
      else {
      $message = 'Sus credenciales son incorectas';
    }
  }
?>





<!DOCTYPE html>
<html lang="en">
<head>
	<title>Administrador</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.minLogin.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/utilLogin.css">
	<link rel="stylesheet" type="text/css" href="css/mainLogin.css">
<!--===============================================================================================-->
</head>
<body>

    
    
         <?php if(!empty($message)): ?>
      <p> <?= $message ?></p>
    <?php endif; ?>
    
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-b-160 p-t-50">
                
				<form action="login.php" method="POST"  class="login100-form validate-form" >
                    
					<span class="login100-form-title p-b-43">
						Cuenta de Administrador
					</span>

                    
                    
                    
                    
                   
					<div class="wrap-input100 rs1 validate-input" data-validate = "Email es requerido">
						<input class="input100" type="text" name="email_adm">
						<span class="label-input100">Email</span>
					</div>


					<div class="wrap-input100 rs2 validate-input" data-validate="Contraseña es requeridad ">
						<input class="input100" type="password" name="contrasena" required>
						<span class="label-input100">Contraseña</span>
					</div>
                    
            
					
                      <input class="login100-form-btn" type="submit" value="Iniciar Sesión">


				</form>
                
<!--
                        <form action="loginphp" method="POST">
      <input name="email_adm" type="text" placeholder="Enter your email"><br /> <br />
      <input name="contrasena" type="password" placeholder="Enter your Password">
        <br /><br />
      <input type="submit" value="Submit">
    </form>
-->

                
			</div>
		</div>
	</div>





<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.minLogin.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/mainLogin.js"></script>

</body>
</html>
