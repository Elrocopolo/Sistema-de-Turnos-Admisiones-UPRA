<?php 
require 'PHPMailer.php';
require 'SMTP.php';
require 'Exception.php';
require 'OAuth.php';

$mail = new PHPMailer\PHPMailer\PHPMailer();

$mail->isSMTP();

$mail->SMTDebug = 0;
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = "sistema.de.turnos.upra@gmail.com";
$mail->Password = "Turnos1234";
$mail->setFrom('sistema.de.turnos.upra@gmail.com', 'Sistema de Turnos Admiciones');
$mail->addAddress('elis.trinidad@upr.edu','Visitante');
$mail->Subject = 'prueba';
$mail->Body = "";






$mail->IsHTML(true);

if($mail->send()){
    echo "notificacion enviada";
}
else{
    echo "mensaje no enviado";
    
}



?>
