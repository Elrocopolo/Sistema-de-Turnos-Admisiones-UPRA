<?php
session_start();

    $first_name = "";
    $last_name = "";
    $name = "";
    $email = "";
    $message = "";
    $errors = array();

$con = mysqli_connect('localhost', 'root', '', 'rulesvan');

    //register
    if (isset($_POST['register'])){
        
        
        $first_name = mysqli_real_escape_string($con, $_POST['first_name']);
        $last_name = mysqli_real_escape_string($con, $_POST['last_name']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $password1 = mysqli_real_escape_string($con, $_POST['password1']);
        $password2 = mysqli_real_escape_string($con, $_POST['password2']);
        
        if (empty($first_name)){
            array_push($errors, "**First Name is required**");
        }
        
        if (empty($last_name)){
            array_push($errors, "**Last Name is required**");
        }  
        
        if (empty($email)){
            array_push($errors, "**Email Address is required**");
        }  
        
        if (empty($password1)){
            array_push($errors, "**Password is required**");
        }        
        
        if ($password1 != $password2){
            array_push($errors, "**Passwords do not match**");
        }
        
        
      $customer_check_query = "SELECT * FROM customer WHERE email='$email' LIMIT 1";
      $result = mysqli_query($con, $customer_check_query);
      $customer = mysqli_fetch_assoc($result);
        
      if ($customer) { // if customer exists

        if ($customer['email'] == $email) {
          array_push($errors, "**Email Address already exists**");
        }
      }

      // Finally, register user if there are no errors in the form
      if (count($errors) == 0) {
        $password = md5 ($password1);//encrypt the password before saving in the database

        $insert_c = "insert into customer 
                    (first_name, last_name, email, password) values ('$first_name', '$last_name', '$email', '$password')";
        mysqli_query($con, $insert_c);
          
        echo "<script>alert('Your registration has been successful! Please Log In to your account.')</script>";
        echo "<script>window.open('login.php', '_Self')</script>";
        //$_SESSION['first_name'] = $first_name;
  	    //$_SESSION['success'] = "You are now logged in";
        //header("location: login.php");

        
      }
    }

//------------------------------------------------------------------------------------------------------------------------------------

    //login
    if (isset($_POST['login'])) {
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $password = mysqli_real_escape_string($con, $_POST['password']);

    if (empty($email)) {
  	     array_push($errors, "**Email Address is required**");
  }
        
    if (empty($password)) {
  	     array_push($errors, "**Password is required**");
  }

  if (count($errors) == 0) {
        $password = md5 ($password);
        $query = "SELECT * FROM customer WHERE email='$email' AND password='$password'";
        $results = mysqli_query($con, $query);
        if (mysqli_num_rows($results) == 1) {
          $_SESSION['email'] = $email;
          $_SESSION['success'] = "You are now logged in";
          header('location: index.php');
        }else {
            array_push($errors, "**Wrong email/password combination**");
  	}
  }
}

//------------------------------------------------------------------------------------------------------------------------------------

    //contact us
    if (isset($_POST['contactUs'])){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $message = $_POST['message'];
        
        if (empty($name)){
            array_push($errors, "**Your Name is required**");
        }
        
        if (empty($email)){
            array_push($errors, "**Your Email Address is required**");
        } 
        
        if (empty($message)){
            array_push($errors, "**A Message is required**");
        }
        

        if (count($errors) == 0) {
            //$mailTo = "ralph.mercado@upr.edu";
            //$headers = "From: ".$email;
            //$txt = "You have received an email from ".$name.".\n\n".$mesage;    
            
            //mail($mailTo, $txt, $headers );
            
            echo "<script>alert('Thank you for contacting us. One of our representatives will be in contact with you shortly regarding your inquiry. If you ever have any questions that require immediate assistance, please call us at +1(787)858-8855.')</script>";
            echo "<script>window.open('index.php', '_Self')</script>";
          
    
        
      }
    }

//------------------------------------------------------------------------------------------------------------------------------------

    //change password
    if (isset($_POST['changePassword'])){
        
        $customer = $_SESSION['email'];
        
        $password0 = mysqli_real_escape_string($con, $_POST['password0']);
        $password1 = mysqli_real_escape_string($con, $_POST['password1']);
        $password2 = mysqli_real_escape_string($con, $_POST['password2']);
        $hash_pass = md5($password0);
        
        $sel_pass = "select * from customer where password = '$hash_pass' and email = '$customer'";
        
        $run_pass = mysqli_query($con, $sel_pass);
        
        $check_pass = mysqli_num_rows($run_pass);
        
        if (empty($password0)){
            array_push($errors, "**Current password is required**");
        }
        
        if (empty($password1)){
            array_push($errors, "**New password is required**");
        } 
        
        if ($password1 != $password2){
            array_push($errors, "**New passwords do not match**");
            
        }
        
        if($check_pass==0){
            array_push($errors, "**Your current password is wrong**");
            
        }
        
        
      if (count($errors) == 0) {
        $password = md5($password1);//encrypt the password before saving in the database

        $update_pass = "update customer set password = '$password' where email = '$customer'";
          
        mysqli_query($con, $update_pass);
          
        $run_update = mysqli_query($con, $update_pass);  
          
        echo "<script>alert('Your password has been changed successfully!')</script>";      
        //echo "<script>window.open('login.php', '_Self')</script>";  
          
        }   


      }

//------------------------------------------------------------------------------------------------------------------------------------

    //personal info
    if (isset($_POST['customerInfo'])){
        
        $customer = $_SESSION['email'];
        
        $first_name = mysqli_real_escape_string($con, $_POST['first_name']);
        $last_name = mysqli_real_escape_string($con, $_POST['last_name']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        //$password = mysqli_real_escape_string($con, $_POST['password']);
        $phone = mysqli_real_escape_string($con, $_POST['phone']);
        $add1 = mysqli_real_escape_string($con, $_POST['add1']);
        $add2 = mysqli_real_escape_string($con, $_POST['add2']);
        $country = mysqli_real_escape_string($con, $_POST['country']);
        $city = mysqli_real_escape_string($con, $_POST['city']);
        $state = mysqli_real_escape_string($con, $_POST['state']);
        $zipcode = mysqli_real_escape_string($con, $_POST['zipcode']);

        if ($email != $customer){
            array_push($errors, "**Email Address cannot be changed**");
            
        }        
        
        if (empty($first_name)){
            array_push($errors, "**First Name is required**");
        }
        
        if (empty($last_name)){
            array_push($errors, "**Last Name is required**");
        }  
        
        if (empty($email)){
            array_push($errors, "**Email Address is required**");
        }  
        
        if (empty($phone)){
            array_push($errors, "**Phone Number is required**");
        }        

        if (empty($add1)){
            array_push($errors, "**Street Name is required**");
        }        
        
        if (empty($add2)){
            array_push($errors, "**Apt Number is required**");
        }
        
        if (empty($city)){
            array_push($errors, "**City is required**");
        }
        
        if (empty($state)){
            array_push($errors, "**State is required**");
        }        
        
        if (empty($zipcode)){
            array_push($errors, "**Zip Code is required**");
        }

        if (count($errors) == 0) {
        
        $update_info = "update customer set first_name = '$first_name', last_name = '$last_name', phone_number = '$phone', street_name = '$add1', apt_number = '$add2', city = '$city', state = '$state', zip_code = '$zipcode', country = '$country' where email = '$customer'";
          
        mysqli_query($con, $update_info);
          
        $run_update = mysqli_query($con, $update_info);   
        

        //$insert_c = "insert into customer 
                    //(first_name, last_name, email, phone_number, street_name, apt_number, city, state, zip_code, country) values ('$first_name', '$last_name', '$email', '$phone', '$add1', '$add2', '$city', '$state', '$zipcode', '$country') where email = '$customer'";
            
        //mysqli_query($con, $insert_c);
          
        echo "<script>alert('Your account information has been changed successfully!')</script>";
        //echo "<script>window.open('login.php', '_Self')</script>";


        
      }
    
        
    }


//------------------------------------------------------------------------------------------------------------------------------------  


    //personal info
    if (isset($_POST['completeOrder'])){
        
        $customer = $_SESSION['email'];
        
        $first_name = mysqli_real_escape_string($con, $_POST['first_name']);
        $last_name = mysqli_real_escape_string($con, $_POST['last_name']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        //$password = mysqli_real_escape_string($con, $_POST['password']);
        $phone = mysqli_real_escape_string($con, $_POST['phone']);
        $add1 = mysqli_real_escape_string($con, $_POST['add1']);
        $add2 = mysqli_real_escape_string($con, $_POST['add2']);
        $country = mysqli_real_escape_string($con, $_POST['country']);
        $city = mysqli_real_escape_string($con, $_POST['city']);
        $state = mysqli_real_escape_string($con, $_POST['state']);
        $zipcode = mysqli_real_escape_string($con, $_POST['zipcode']);

        if ($email != $customer){
            array_push($errors, "**Email Address cannot be changed**");
            
        }        
        
        if (empty($first_name)){
            array_push($errors, "**First Name is required**");
        }
        
        if (empty($last_name)){
            array_push($errors, "**Last Name is required**");
        }  
        
        if (empty($email)){
            array_push($errors, "**Email Address is required**");
        }  
        
        if (empty($phone)){
            array_push($errors, "**Phone Number is required**");
        }        

        if (empty($add1)){
            array_push($errors, "**Street Name is required**");
        }        
        
        if (empty($add2)){
            array_push($errors, "**Apt Number is required**");
        }
        
        if (empty($city)){
            array_push($errors, "**City is required**");
        }
        
        if (empty($state)){
            array_push($errors, "**State is required**");
        }        
        
        if (empty($zipcode)){
            array_push($errors, "**Zip Code is required**");
        }

        if (count($errors) == 0) {
        
        $update_info = "update customer set first_name = '$first_name', last_name = '$last_name', phone_number = '$phone', street_name = '$add1', apt_number = '$add2', city = '$city', state = '$state', zip_code = '$zipcode', country = '$country' where email = '$customer'";
          
        mysqli_query($con, $update_info);
          
        $run_update = mysqli_query($con, $update_info);   
        

        //$insert_c = "insert into customer 
                    //(first_name, last_name, email, phone_number, street_name, apt_number, city, state, zip_code, country) values ('$first_name', '$last_name', '$email', '$phone', '$add1', '$add2', '$city', '$state', '$zipcode', '$country') where email = '$customer'";
            
        //mysqli_query($con, $insert_c);
          
        //echo "<script>window.open('index.php', '_Self')</script>";
        //echo "<script>window.open('login.php', '_Self')</script>";

        }
    }
?>