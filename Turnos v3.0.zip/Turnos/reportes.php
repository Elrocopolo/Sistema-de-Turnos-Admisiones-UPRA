<?php 
session_start();
require 'database.php';
$desde='';
$hasta= '';

$desde=$_POST['desde'];
$hasta=$_POST['hasta'];

$lista ='';
$lista2='';

print_r($desde);

if (!empty($_POST['desde']) && !empty($_POST['hasta']))  
  {
    $vista= $conn->prepare("SELECT * FROM turno natural join visitante WHERE fecha_atendido >= '$desde' and fecha_atendido <= '$hasta' and estado = 'Completado' ");
    $vista->execute();
    $lista= $vista->fetchAll(PDO::FETCH_ASSOC);
 
  
 //print_r($lista);     

      
  if ($lista) {
      $message = 'Successfully created reporte';
      
          $vista5= $conn->prepare("SELECT COUNT(turno_id) FROM turno natural join visitante WHERE fecha_atendido >= '$desde' and fecha_atendido <= '$hasta' and estado = 'Completado' ");
    $vista5->execute();
    $lista5= $vista5->fetch(PDO::FETCH_ASSOC);
      $ncontador5 = $lista5['COUNT(turno_id)'];
 
  
 print_r($ncontador5);     

      
      
      
      
      
      
      
      
    } else {
      $message = 'Sorry there must have been an issue turno';
    }
  }
if (!empty($_POST['desde']) && !empty($_POST['hasta']))  
  {
    $vista2= $conn->prepare("SELECT * FROM turno natural join visitante WHERE fecha_atendido >= '$desde' and fecha_atendido <= '$hasta' and estado = 'No Completado' ");
    $vista2->execute();
    $lista2= $vista2->fetchAll(PDO::FETCH_ASSOC);
 
  
 //print_r($lista2);     

      
  if ($lista2) {
      $message = 'Successfully created reporte';
      
          $vista4= $conn->prepare("SELECT COUNT(turno_id) FROM turno natural join visitante WHERE fecha_atendido >= '$desde' and fecha_atendido <= '$hasta' and estado = 'No Completado' ");
    $vista4->execute();
    $lista4= $vista4->fetch(PDO::FETCH_ASSOC);
      $ncontador4 = $lista4['COUNT(turno_id)'];
 
  
 print_r($ncontador4);     

      
    } else {
      $message = 'Sorry there must have been an issue turno';
    }
  }




?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Tabla Turnos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">

    <link href="css/bootstrap-datetimepicker.css" rel="stylesheet">
    <script src="js/bootstrap-datetimepicker.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>






<body id="page-top">



    <div id="wrapper">
        <nav class="navbar navbar-dark align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0">
       
            <div class="container-fluid d-flex flex-column p-0">
            
                <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="">
                    <div class="sidebar-brand-icon rotate-n-15"></div>
                    <div class="sidebar-brand-text mx-3"><span>admin panel</span></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="nav navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link active" href="index.php"><i class="fas fa-home"></i><span>Inicio</span></a>
                        <a class="nav-link active" href="reportes.php"><i class="fas fa-users-cog"></i><span>Reportes</span></a>
                        <a class="nav-link active" href="Tabla-Turnos.php"><i class="fas fa-table"></i><span>Tabla de Turnos</span></a>
                        <?php if($_SESSION['tipo']==1) { ?>
                        <a class="nav-link active"
                            href="Crear-Administrador.php"><i class="fas fa-user-plus"></i><span>Crear Administrador</span></a>
                        <a class="nav-link active" href="manejaradministrador.php">
                        <i class="fas fa-user-times"></i><span>Manejar Administrador</span></a>
                         <?php }?>
                        <a class="nav-link active" href="logout.php">
                        <i class="fa fa-sign-out" style="font-size:18px" ></i><span>Logout</span></a>
                        
                            
                    </li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                          <h5>Bienvenido: <?php echo $_SESSION['user_id']?></h5>
                    <div class="container-fluid"><button class="btn btn-link d-md-none rounded-circle mr-3" id="sidebarToggleTop" type="button"><i class="fas fa-bars"></i></button></div>
                </nav>
  <!------------------------------------------------------------------------------------------->
               
            <?php    if($lista)
                {?>
                <div class="container-fluid" >
<h2 class="text-center" style="color:black;">   Turnos completados (<?php echo $ncontador5 ?>)</h2>


                  <link rel="stylesheet" href="styles.css">
                  <table class="table table-dark">
                      
                    <thead>
                   
                      <tr>
                        <th scope="col"># de turno</th>
                        <th scope="col">Administrador</th>
                        <th scope="col">Nombre Visitante</th>
                        <th scope="col">Email</th>
                        <th scope="col">Servicio</th>
                        <th scope="col">Comentario</th>
                        <th scope="col"></th>

                      </tr>
                    </thead>
                    <tbody>
                       <?php  foreach($lista as $turnos)  {    ?> 
                      <tr>
                        <th scope="col"><?php echo $turnos['turno_id'];?></th>
                        <th scope="col"><?php echo $turnos['email_adm'];?></th>
                        <th scope="col"><?php echo $turnos['nombre'];?><?php echo " "?><?php echo $turnos['apellido'];?></th>
                        <th scope="col"><?php echo $turnos['email_visitante'];?></th>
                        <th scope="col"><?php echo $turnos['tipo_servicio'];?></th>
                        <th scope="col"><?php echo $turnos['comentario_procesa'];?></th>
                        <th scope="col"></th>

                      </tr>
                        <?php    }    ?> 
                     



                    </tbody>
                  </table>




                </div>
             <?php   } ?>
                
                <?php    if($lista2)
                {?>
                  
                <div class="container-fluid" >
<h2 class="text-center" style="color:black;">   Turnos no completados (<?php echo $ncontador4 ?>)</h2>
                  <link rel="stylesheet" href="styles.css">
                  <table class="table table-dark">
                      
                    <thead>
                   
                      <tr>
                        <th scope="col"># de turno</th>
                        <th scope="col">Administrador</th>
                        <th scope="col">Nombre Visitante</th>
                        <th scope="col">Email</th>
                        <th scope="col">Servicio</th>
                        <th scope="col">Comentario</th>
                        <th scope="col"></th>

                      </tr>
                    </thead>
                    <tbody>
                       <?php  foreach($lista2 as $turnos)  {    ?> 
                      <tr>
                        <th scope="col"><?php echo $turnos['turno_id'];?></th>
                        <th scope="col"><?php echo $turnos['email_adm'];?></th>
                        <th scope="col"><?php echo $turnos['nombre'];?><?php echo " "?><?php echo $turnos['apellido'];?></th>
                        <th scope="col"><?php echo $turnos['email_visitante'];?></th>
                        <th scope="col"><?php echo $turnos['tipo_servicio'];?></th>
                        <th scope="col"><?php echo $turnos['comentario_procesa'];?></th>
                        <th scope="col"></th>

                      </tr>
                        <?php    }    ?> 
                     



                    </tbody>
                  </table>




                </div>
             <?php   } ?>
                <head>

 <form action="reportes.php"  method="POST">

      <div class="d-flex justify-content-center">

        <td class="text-left"><!--tiempo funcion-->
          <input name="desde" id="datepicker" width="276" />
          <script>
              $('#datepicker').datetimepicker({
                  
                  format: 'yyyy-mm-dd HH:MM ',
                  uiLibrary: 'bootstrap4'

              });
          </script>
              
        </td>
            <div class="d-flex justify-content-center  col-md-2">

          <h0 class="text-center" style="color:black;"><font size="5">Hasta</font></h0>
           </div>

  <div class="d-flex justify-content-center  col-md-3">
        <td class="text-left"><!--tiempo funcion-->
          <input name="hasta" id="datepicker2" width="276" />
          <script>
              $('#datepicker2').datetimepicker({
                 
                  format: 'yyyy-mm-dd HH:MM ',
                  uiLibrary: 'bootstrap4'
              });
          </script>
        </td>
    </div>
          
<input  class="btn btn-success badge-pill" type="submit" value="Hacer reporte"  >

  <!------------------------------------------------------------------------------------------->


    <div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/theme.js"></script>



</body>







</html>
