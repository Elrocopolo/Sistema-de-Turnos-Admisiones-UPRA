<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Ajustes de Cuenta</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/login-form---Ambrodu-1.css">
    <link rel="stylesheet" href="assets/css/login-form---Ambrodu.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form-1.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form.css">
</head>

<body id="page-top">
    <div id="wrapper">
        <nav class="navbar navbar-dark align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0">
            <div class="container-fluid d-flex flex-column p-0">
                <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div class="sidebar-brand-icon rotate-n-15"></div>
                    <div class="sidebar-brand-text mx-3"><span>admin panel</span></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="nav navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item" role="presentation"><a class="nav-link active" href="index.php"><i class="fas fa-home"></i><span>Home</span></a><a class="nav-link active" href=""><i class="fas fa-users-cog"></i><span>Ajustes de Cuenta</span></a><a class="nav-link active"
                            href="Crear-Administrador.html"><i class="fas fa-user-plus"></i><span>Crear Administrador</span></a><a class="nav-link active" href="manejaradministrador.php"><i class="fas fa-user-times"></i><span>Eliminar Administrador</span></a><a class="nav-link active"
                            href="Tabla-Turnos.php"><i class="fas fa-table"></i><span>Ver Tabla de Turnos</span></a></li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                    <div class="container-fluid"><button class="btn btn-link d-md-none rounded-circle mr-3" id="sidebarToggleTop" type="button"><i class="fas fa-bars"></i></button></div>
                </nav>
                <div class="container-fluid ">
                    <div class="d-sm-flex justify-content-between align-items-center mb-4"></div>
                </div>
                <div class="d-flex justify-content-center profile profile-view" id="profile">
                    <div class="row">
                        <div class="col-md-12 alert-col relative">
                            <div class="alert alert-info absolue center" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><span>Profile save with success</span></div>
                        </div>
                    </div>
                    <form>
                        <div class="form-row profile-row">
                            <div class="col-md-4 relative">
                                <div class="avatar">
                                    <div class="avatar-bg center"></div>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <hr>
                                <div class="form-group"><label>Email Actual&nbsp;</label><input class="form-control" type="email" autocomplete="off" required="" name="email"></div>
                                
                                
                                <div class="form-group"><label>Email Nuevo </label><input class="form-control" type="email" autocomplete="off" required="" name="email"></div>
                                
                                
                                <div class="form-row">
                                    <div class="col-sm-12 col-md-6">
                                        <div class="form-group"><label>Contraseña Nueva </label><input class="form-control" type="password" name="password" autocomplete="off" required=""></div>
                                    </div>
                                    <div class="col-sm-12 col-md-6">
                                        <div class="form-group"><label>Confirme la Contraseña</label><input class="form-control" type="password" name="confirmpass" autocomplete="off" required=""></div>
                                    </div>
                                </div>
                                <hr>
                                <div class="form-row">
                                    <div class="col-md-12 content-right"><button class="btn btn-primary form-btn" type="submit">Guardar </button><!--<button class="btn btn-danger form-btn" type="reset">Cancelar </button></div>-->
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/Profile-Edit-Form.js"></script>
    <script src="assets/js/theme.js"></script>
</body>

</html>
