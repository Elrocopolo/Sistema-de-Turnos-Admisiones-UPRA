

<?php
require 'PHPMailer.php';
require 'SMTP.php';
require 'Exception.php';
require 'OAuth.php';

require 'database.php';
 $message = '';

/*print_r($_POST['email_visitante']);
print_r($_POST['nombre']);
print_r($_POST['apellido']);
print_r($_POST['numero_telefono']);
print_r($_POST['tipo_servicio']);
print_r($_POST['servicio']);*/
//caso de otros servicios
if (!empty($_POST['email_visitante']) && !empty($_POST['nombre'])&& !empty($_POST['apellido'])&& !empty($_POST['numero_telefono']))  
  {
    $sql = "INSERT INTO visitante (email_visitante,nombre,apellido,numero_telefono) VALUES (:email_visitante,:nombre,:apellido,:numero_telefono)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email_visitante', $_POST['email_visitante']);
    $stmt->bindParam(':nombre', $_POST['nombre']);
    $stmt->bindParam(':apellido', $_POST['apellido']);
    $stmt->bindParam(':numero_telefono', $_POST['numero_telefono']);
  

      
  if ($stmt->execute()) {
      $message = 'Successfully created Turno';
      
    } else {
      $message = 'Sorry there must have been an issue turno';
    }
  }

if (empty($_POST['email_visitante']) && !empty($_POST['nombre'])&& !empty($_POST['apellido']) && empty($_POST['numero_telefono']))  
  {
    $sql = "INSERT INTO visitante (nombre,apellido) VALUES (:nombre,:apellido)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':nombre', $_POST['nombre']);
    $stmt->bindParam(':apellido', $_POST['apellido']);
  

      
  if ($stmt->execute()) {
      $message = 'Successfully created Turno';
      
    } else {
      $message = 'Sorry there must have been an issue turno';
    }
  }

if (!empty($_POST['email_visitante']) && !empty($_POST['nombre'])&& !empty($_POST['apellido']) && empty($_POST['numero_telefono']))  
  {
    $sql = "INSERT INTO visitante (nombre,apellido) VALUES (:nombre,:apellido)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':nombre', $_POST['nombre']);
    $stmt->bindParam(':apellido', $_POST['apellido']);
  

      
  if ($stmt->execute()) {
      $message = 'Successfully created Turno';
      
    } else {
      $message = 'Sorry there must have been an issue turno';
    }
  }

if (empty($_POST['email_visitante']) && !empty($_POST['nombre'])&& !empty($_POST['apellido']) && !empty($_POST['numero_telefono']))  
  {
    $sql = "INSERT INTO visitante (nombre,apellido) VALUES (:nombre,:apellido)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':nombre', $_POST['nombre']);
    $stmt->bindParam(':apellido', $_POST['apellido']);
  

      
  if ($stmt->execute()) {
      $message = 'Successfully created Turno';
      
    } else {
      $message = 'Sorry there must have been an issue turno';
    }
  }




$id_padre = $conn->prepare('select max(visitante_id) from visitante ');

    $id_padre->execute();
    $resulta = $id_padre->fetch(PDO::FETCH_ASSOC);

$id = $resulta['max(visitante_id)'];

$esperando = $conn->prepare("SELECT count(turno_id) FROM turno WHERE  estado = 'esperandoturno'");

    $esperando->execute();
    $resulta = $esperando->fetch(PDO::FETCH_ASSOC);

$esperandoturno = $resulta['count(turno_id)'];


                    
print($id);
print($esperandoturno);

if (empty($_POST['email_visitante']) && !empty($_POST['servicio']))  
  {
    $sql = "INSERT INTO turno (visitante_id,tipo_servicio,fecha_solicitud,estado) VALUES (:visitante_id,:tipo_servicio,NOW(),'esperandoturno')";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':visitante_id', $id);
    $stmt->bindParam(':tipo_servicio', $_POST['servicio']);

 

      
  if ($stmt->execute()) {
      $message = 'Successfully created Turno';
      
    } else {
      $message = 'Sorry there must have been an issue turno';
    }
  }



if (!empty($_POST['email_visitante']) && !empty($_POST['servicio']))  
  {
    $sql = "INSERT INTO turno (visitante_id,tipo_servicio,fecha_solicitud,estado) VALUES (:visitante_id,:tipo_servicio,NOW(),'esperandoturno')";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':visitante_id', $id);
    $stmt->bindParam(':tipo_servicio', $_POST['servicio']);


      
  if ($stmt->execute()) {
      
      $id_padre9= $conn->prepare("SELECT* from turno natural join visitante where visitante_id ='$id' ");

    $id_padre9->execute();
    $resulta9 = $id_padre9->fetch(PDO::FETCH_ASSOC);


      
      $destinatario9=$resulta9['email_visitante'];
    $nombre9 =$resulta9['nombre'];
    $apellido9= $resulta9['apellido'];
      $turno9 = $resulta9['turno_id'];
      
      
      
      $message = 'Successfully created Turno';
      $destinatario= $_POST['email_visitante'];
      $mail = new PHPMailer\PHPMailer\PHPMailer();

$mail->isSMTP();

$mail->SMTDebug = 0;
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = "sistema.de.turnos.upra@gmail.com";
$mail->Password = "Turnos1234";
$mail->setFrom('sistema.de.turnos.upra@gmail.com', 'Sistema de Turnos Admiciones');
$mail->addAddress($destinatario9,'Visitante');
$mail->Subject = 'Notificacion de turno';
$mail->Body = $nombre9;
$mail->Body .=" ";
$mail->Body .=$apellido9;
$mail->Body .= " su turno es el ";
$mail->Body .= $turno9;
$mail->Body .=", quedan $esperandoturno turnos antes que el suyo.";
   






$mail->IsHTML(true);

if($mail->send()){
    echo "notificacion enviada";
}
else{
    echo "mensaje no enviado";
    
}
      
      
      
      
      
      
      
      
      
      
      
      
      
      
    } else {
      $message = 'Sorry there must have been an issue turno';
    }
  }


if (empty($_POST['email_visitante']) && !empty($_POST['tipo_servicio']) &&empty($_POST['servicio']))  
  {
    $sql = "INSERT INTO turno (visitante_id,tipo_servicio,fecha_solicitud,estado) VALUES (:visitante_id,:tipo_servicio,NOW(),'esperandoturno')";
    $stmt = $conn->prepare($sql);
        $stmt->bindParam(':visitante_id', $id);

    $stmt->bindParam(':tipo_servicio', $_POST['tipo_servicio']);


      
  if ($stmt->execute()) {
      $message = 'Successfully created Turno';
      
    } else {
      $message = 'Sorry there must have been an issue turno';
    }
}

  if (!empty($_POST['email_visitante']) && !empty($_POST['tipo_servicio']) &&empty($_POST['servicio']))  
  {
    $sql = "INSERT INTO turno (visitante_id,tipo_servicio,fecha_solicitud,estado) VALUES (:visitante_id,:tipo_servicio,NOW(),'esperandoturno')";
    $stmt = $conn->prepare($sql);
        $stmt->bindParam(':visitante_id', $id);

    $stmt->bindParam(':tipo_servicio', $_POST['tipo_servicio']);


      
      
  if ($stmt->execute()) {
      $id_padre9= $conn->prepare("SELECT* from turno natural join visitante where visitante_id ='$id' ");

    $id_padre9->execute();
    $resulta9 = $id_padre9->fetch(PDO::FETCH_ASSOC);


      
      $destinatario9=$resulta9['email_visitante'];
    $nombre9 =$resulta9['nombre'];
    $apellido9= $resulta9['apellido'];
      $turno9 = $resulta9['turno_id'];
      
      
      
      $message = 'Successfully created Turno';
      $destinatario= $_POST['email_visitante'];
      $mail = new PHPMailer\PHPMailer\PHPMailer();

$mail->isSMTP();

$mail->SMTDebug = 0;
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = "sistema.de.turnos.upra@gmail.com";
$mail->Password = "Turnos1234";
$mail->setFrom('sistema.de.turnos.upra@gmail.com', 'Sistema de Turnos Admiciones');
$mail->addAddress($destinatario9,'Visitante');
$mail->Subject = 'Notificacion de turno';
$mail->Body = $nombre9;
$mail->Body .=" ";
$mail->Body .=$apellido9;
$mail->Body .= " su turno es el ";
$mail->Body .= $turno9;
$mail->Body .=", quedan $esperandoturno turnos antes que el suyo.";
   






$mail->IsHTML(true);

if($mail->send()){
    echo "notificacion enviada";
}
else{
    echo "mensaje no enviado";
    
}
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      $message = 'Successfully created Turno';
      
    } else {
      $message = 'Sorry there must have been an issue turno';
    }
  }


print_r($message);
      

?>




<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">



    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main2.css" rel="stylesheet" media="all">

    <script type="text/javascript">
    function CheckServicio(val){
     var element=document.getElementById('servicio');
     if(val=='Opciones'||val=='otros')
       element.style.display='block';
     else  
       element.style.display='none';
    }

    </script> 

</head>

<body>


    <div class="page-wrapper bg-gra-03 p-t-45 p-b-50">
        <div class="wrapper wrapper--w790">
            <div class="card card-5">
                <div class="card-heading">
                    <h2 class="title">Bienvenidos al Sistema de Turnos de Admisiones</h2>
                </div>
                

    
                <div class="card-body">
                    
                    <form action="Visitante-Formulario.php"  method="POST">
                        
                        <div class="form-row m-b-55">
                            <div class="name">Nombre</div>
                            <div class="value">
                                <div class="row row-space">
                                    <div class="col-2">
                                        <div class="input-group-desc">
                                            
                                            <input class="input--style-5" type="text" name="nombre" maxlength="40"  required >
                                            
                                            <label class="label--desc">Nombre</label>
                                        </div>
                                    </div>
                                    <div class="col-2">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="apellido" maxlength="40" required>
                                            <label class="label--desc">Apellido</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                            <div class="value">
                                <div class="input-group">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Email</div>
                            <div class="value">
                                <div class="input-group">
                                    
                                    <input class="input--style-5" type="email" name="email_visitante" maxlength="50">
                                    
                                    <label class="label--desc">Email</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Número de Teléfono</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="numero_telefono" maxlength="11"  >
                                    <label class="label--desc">Número de Teléfono</label>
                                </div>
                            </div>
                        </div>

                        <!--<div class="form-row">
                            <div class="name">Tipo de Estudiante</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                        <select name="subject">
                                            <option disabled="disabled" selected="selected">Opciones</option>
                                            <option>Estudiante de Nuevo Ingreso</option>
                                            <option>Estudiante de Transferencia</option>

                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>

                            </div>
                        </div>-->
                        <div class="form-row">
                            <div class="name">Servicios</div>
                            <div   class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                        <select name="tipo_servicio" required  onchange='CheckServicio(this.value);  '>
                                           <option  value=""  >Opciones</option>
                                            <option value="Solicitar Documentos">Solicitar Documentos</option>
                                            <option value="Entregar Documentos">Entregar Documentos</option>
                                            <option value="Orientacion">Orientación</option>
                                            <option value="otros">Otros</option>    
                                        </select>
                                        
                                        <div class="select-dropdown"></div>
                                    </div>
                                  </div>
                              </div>
                          </div>
                        
                        <div class="form-row">
                            <div class="name"></div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" placeholder="*Escriba motivo de su visita" name="servicio" id="servicio" style='display:none;' />  
                                </div>
                            </div>
                        </div>




          <!--              <div class="form-row p-t-20">
                            <label class="label label--block">Are you an existing customer?</label>
                            <div class="p-t-15">
                                <label class="radio-container m-r-55">Yes
                                    <input type="radio" checked="checked" name="exist">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="radio-container">No
                                    <input type="radio" name="exist">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                      </div>   -->
                        <div>
<!--                            <button class="btn btn--radius-2 btn--red" type="submit" name="formulario" >Enviar</button>-->
                            
                            <input class="btn btn--radius-2 btn--red" type="submit" value="Enviar">

                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->
