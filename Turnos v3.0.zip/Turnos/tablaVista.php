<?php
require 'database.php';

?>

<head>
    <meta http-equiv="refresh" content="5"><!--auto refresh 5 segundos -->

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Tabla Turnos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>



    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
</head>

<body>
    
<?php
    
    
    $records = $conn->prepare("SELECT turno_id,nombre,apellido,tipo_servicio FROM turno natural join visitante WHERE estado = 'esperandoturno'");
    $records->execute();
    $results = $records->fetchAll(PDO::FETCH_ASSOC);
              //print_r($results);
    
    ?>
    <?php
    
    
    $records1 = $conn->prepare("SELECT turno_id,nombre,apellido,tipo_servicio FROM turno natural join visitante WHERE estado = 'atendiendo'");
    $records1->execute();
    $results1 = $records1->fetchAll(PDO::FETCH_ASSOC);
              //print_r($results);
    
    ?>
    
    
    
    
                      
    <div class="container col-md-6 float-left">
  <h2 class="text-center" style="color:black;" >Atendiendose</h2>
  <table class="table table-success table-striped">
    <thead>
      <tr>
          
        <th class="text-center" style="color:black;" ># de turno</th>
        <th class="text-center" style="color:black;" >Nombre</th>
       
       
      </tr>
    </thead>
      
    <tbody>
        <?php  foreach($results1 as $turnos)  {    ?> 
      <tr>
        <td class="text-center" style="color:black;" ><font size="10"><?php echo $turnos['turno_id']; ?></font></td>
        <td class="text-center" style="color:black;" ><font size="10"><?php echo $turnos['nombre'];echo"  "; echo $turnos['apellido'];   ?></font></td>
      
      </tr>
      
      <?php }?>
        
    </tbody>
  </table>
</div>

<div class="container col-md-6 float-right">
      <h2 class="text-center" style="color:black;">Visitante</h2>
  <table class="table table-primary table-striped">
    <thead>
      <tr>
        <th class="text-center" style="color:black;" ># de turno</th>
        <th class="text-center" style="color:black;">Nombre</th>
       
       
      </tr>
    </thead>
      
    <tbody>
        <?php  foreach($results as $turnos)  {    ?> 
      <tr>
        <td class="text-center" style="color:black;" ><font size="6"><?php echo $turnos['turno_id']; ?></font></td>
        <td class="text-center" style="color:black;" ><font size="6"><?php echo $turnos['nombre'];echo"  "; echo $turnos['apellido'];   ?></font></td>
      
      </tr>
      
      <?php }?>
        
    </tbody>
  </table>
</div>
 
 
     
    
    
 
    
    
    
    
</body>
