<?php

$con = mysqli_connect("localhost","root","","rulesvan");


//cart
function cart(){
    
    global $con;
    
    if(isset($_GET['add_cart'])){
        
        $customer = $_SESSION['email'];
        
        $prod_id = $_GET['add_cart'];
        
        $check_prod = "select * from cart where email='$customer' and prod_id='$prod_id'";
        
        $run_check = mysqli_query($con, $check_prod);
        
        if(mysqli_num_rows($run_check>0)){
            
            echo "";
        }
        else{
            
            $insert_prod = "insert into cart (email, prod_id) values('$customer', '$prod_id')";
            
            $run_prod = mysqli_query($con, $insert_prod);
            
            echo "<script>window.open('shop.php', '_Self')</script>";
        }
    }
    
}




//------------------------------------------------------------------------------------------------------------------------------------
//getting the categories
function getCats(){
    
  global $con;
    
  $get_cats = "SELECT DISTINCT prod_category FROM product"; 
    
  $run_cats = mysqli_query($con, $get_cats);
    
  while ($row_cats = mysqli_fetch_array($run_cats)){
      
      $prod_category = $row_cats['prod_category'];
   
  echo "<li><a href='shop.php?cat=$prod_category'>$prod_category</a></li>";      
      
  }  
    
}


//------------------------------------------------------------------------------------------------------------------------------------

//display all products
function getAllItems(){
    
        if(!isset($_GET['cat'])){

        global $con;

        $get_items = "select * from product order by RAND()";
        
        #database connection, query
           
        $run_items = mysqli_query($con, $get_items);
    
        while($row_items=mysqli_fetch_array($run_items)){
    
            $prod_id = $row_items['prod_id'];
            $prod_name = $row_items['prod_name'];
            $prod_category = $row_items['prod_category'];
            $prod_price = $row_items['prod_price'];
            $prod_picture = $row_items['prod_picture'];
            
            
            echo "
                    <tr>
					<th scope='row'>$prod_id</th>
					<td>$prod_name</td>
					<td>$prod_category</td>
                    <td>$$prod_price</td>
                    <td><a href='product-details.php?prod_id=$prod_id'><img src='images/product/$prod_picture' alt='' style='width:204px;'>Details</a></td>
                    
					</tr>
                    
                    
                ";
                
        }
        }
}

//------------------------------------------------------------------------------------------------------------------------------------

//display products from a category
function getCatItems(){
    
        if(isset($_GET['cat'])){
            
            $cat_name = $_GET['cat'];

        global $con;

        $get_cat_items = "select * from product where prod_category='$cat_name' order by RAND()";
        
        #database connection, query
           
        $run_cat_items = mysqli_query($con, $get_cat_items);
            
        $count_cats = mysqli_num_rows($run_cat_items);
            
        while($row_cat_items=mysqli_fetch_array($run_cat_items)){
    
            $prod_id = $row_cat_items['prod_id'];
            $prod_name = $row_cat_items['prod_name'];
            $prod_category = $row_cat_items['prod_category'];
            $prod_price = $row_cat_items['prod_price'];
            $prod_picture = $row_cat_items['prod_picture'];
            
            if($count_cats==0){
                
            echo"<h2>There is no products in this category!</h2>";  
                
            }
            else {
                echo "
                    <tr>
					<th scope='row'>$prod_id</th>
					<td>$prod_name</td>
					<td>$prod_category</td>
                    <td>$$prod_price</td>
                    <td><a href='product-details.php?prod_id=$prod_id'><img src='images/product/$prod_picture' alt='' style='width:204px;'>Details</a></td>
					</tr>
                    
                ";
            }
        }
        }
}




?>