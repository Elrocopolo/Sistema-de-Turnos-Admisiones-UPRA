<?php
require 'database.php';

 session_start();

if(!isset($_SESSION['user_id'])) 
    {
       header("Location:/Turnos/login.php"); 
    }
print_r($_SESSION['user_id']);

$administrador= $_SESSION['user_id'];
               
              
$comentario=$_POST['comentario'];

echo  $comentario;

$email_adm=$_POST['email_adm'];

$estado=$_POST['estado'];


echo $email_adm;

echo $estado;

if($estado==0)
{

    $estadoActivo=1;
    
$sql = $conn->prepare("UPDATE administrador SET activo_admin = '$estadoActivo' WHERE email_adm = '$email_adm'");

$sql->execute();

 

    if($sql)
    {
       // header("Location:/Turnos/manejaradministrador.php");
        
        if (!empty($_POST['email_adm']) && !empty($_POST['comentario'])  )  
        {
        
         $sql2 = "INSERT INTO editado (email_adm, email_adm_editado,fecha_editado,operacion,comentario_editado) VALUES ('$administrador',:email_adm_editado,NOW(),'Activado','$comentario')";
    $stmt2 = $conn->prepare($sql2);
      
       $stmt2->bindParam(':email_adm_editado', $_POST['email_adm']);
       
        $stmt2->execute();
  
       
        print_r('tmo ACTIVE');

        
        }
        
        
        if (!empty($_POST['email_adm']) && empty($_POST['comentario'])  )  
        {
        
         $sql4 = "INSERT INTO editado (email_adm, email_adm_editado,fecha_editado,operacion) VALUES ('$administrador',:email_adm_editado,NOW(),'Activado')";
    $stmt4 = $conn->prepare($sql4);
      
       $stmt4->bindParam(':email_adm_editado', $_POST['email_adm']);
       
        $stmt4->execute();
        
             print_r('no tiene comentario');

  }
       
             header("location:/Turnos/manejaradministrador.php"); 

        
        
        
}
    
    
    
    
    
    else
    {   
        echo "Insercion no exitosa";
    }
  

}


if($estado==1)
{

    $estadoDes=0;
    
$sql = $conn->prepare("UPDATE administrador SET activo_admin = '$estadoDes' WHERE email_adm = '$email_adm'");

$sql->execute();



    if($sql)
    {
        header("Location:/Turnos/manejaradministrador.php");
        
        if (!empty($_POST['email_adm']) && !empty($_POST['comentario'])  )  
        {
            
            
        
        $sql3 = "INSERT INTO editado (email_adm, email_adm_editado,fecha_editado,operacion,comentario_editado) VALUES ('$administrador',:email_adm_editado,NOW(),'Descativado','$comentario')";
    $stmt3 = $conn->prepare($sql3);
      
       $stmt3->bindParam(':email_adm_editado', $_POST['email_adm']);
        
        $stmt3->execute();
  
        print_r('tmo ACTIVE');
            
            }
        
          if (!empty($_POST['email_adm']) && empty($_POST['comentario'])  )  
              
          {    $sql5 = "INSERT INTO editado (email_adm, email_adm_editado,fecha_editado,operacion) VALUES ('$administrador',:email_adm_editado,NOW(),'Descativado')";
    $stmt5 = $conn->prepare($sql5);
      
       $stmt5->bindParam(':email_adm_editado', $_POST['email_adm']);
        
        $stmt5->execute();
  
        print_r('no tiene comentario');
            
      header("location:/Turnos/manejaradministrador.php"); 



}
        
        
        

}else
    {   
        echo "Insercion no exitosa";
    }
  

}
    
    
    
    
    



 

?>