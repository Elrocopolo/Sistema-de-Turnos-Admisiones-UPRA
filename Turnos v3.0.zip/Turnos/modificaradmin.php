<?php

require 'database.php';

   
echo $email_adm= $_POST["email_adm"];
                     
 ?>
         


<!DOCTYPE html>


<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Ajustes de Cuenta</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/login-form---Ambrodu-1.css">
    <link rel="stylesheet" href="assets/css/login-form---Ambrodu.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form-1.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form.css">
</head>

<body id="page-top">
   
    
    
                    
                    <?php
                    
                    $vista= $conn->prepare("select * from administrador where email_adm = '$email_adm' ");
                    $vista->execute();
                    $lista= $vista->fetchAll(PDO::FETCH_ASSOC);
                   // print_r($lista);

            
                
          
                ?>
                    
                    
                    <?php  foreach($lista as $cuenta)  {    ?> 
   
                    
                    <form action="manejadorAdminProceso.php" method="POST" align="center">
                        
                        <div class="form-row profile-row">
                            <div class="col-md-4 relative">
                                <div class="avatar">
                                    <div class="avatar-bg center"></div>
                                </div>
                            </div>
                        </div>
                        
                            <div class="col-md-8">
                                <hr>
                                <div class="form-group"><label>Email Actual&nbsp;</label><input class="form-control"  autocomplete="off" readonly name="email1" value="<?php echo $cuenta['email_adm']; ?>"></div>
                                
                                
<!--
                                <div class="form-group"><label>Email Nuevo </label>
                                    
                                    <input class="form-control" type="email"  required name="email_adm"></div>
                                
-->
                                
                                <div class="form-row">
                                    <div class="col-sm-12 col-md-6">
                                        <div class="form-group"><label>Contraseña Vieja </label>
                                            
                                            
                                            <input class="form-control"  name="contrasena1" readonly  autocomplete="off"  value="<?php echo $cuenta['contrasena']; ?>"></div>
                                    </div>
                                    
                                    
                              <div class="col-sm-12 col-md-6">
                                        <div class="form-group"><label>Contraseña Nueva</label>
                                            
                                            <input class="form-control" required name="contrasena"    value=""></div>
                                    </div>
                                </div>
                                <hr>
                                
                                
                                 <input type="submit" value=Enviar>
                        </div>
                            <?php } ?>  
                            
                      
                     
                    </form>
                            
                      
                               
          
       
                               
                               
                        
                </div>
            </div>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/Profile-Edit-Form.js"></script>
    <script src="assets/js/theme.js"></script>
</body>

</html>
