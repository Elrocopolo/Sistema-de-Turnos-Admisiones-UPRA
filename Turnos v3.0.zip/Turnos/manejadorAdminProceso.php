<?php
require 'database.php';

 session_start();

if(!isset($_SESSION['user_id'])) 
    {
       header("Location:/Turnos/login.php"); 
    }
print_r($_SESSION['user_id']);

              
  $administrador= $_SESSION['user_id'];
            


                   


//$email_adm=$_POST['email_adm'];



$contrasena=$_POST['contrasena'];

$email1=$_POST['email1'];               
              

$contrasena1=$_POST['contrasena1'];

$comentario=$_POST['comentario'];

$sql = $conn->prepare("UPDATE administrador SET contrasena = '$contrasena' WHERE email_adm = '$email1'");

$sql->execute();



    if($sql)
    {
        
         if (!empty($_POST['email1']) && !empty($_POST['comentario'])  )  
        {
            
            
        
        $sql3 = "INSERT INTO editado (email_adm, email_adm_editado,fecha_editado,operacion,comentario_editado) VALUES ('$administrador',:email_adm_editado,NOW(),'editado','$comentario')";
    $stmt3 = $conn->prepare($sql3);
      
       $stmt3->bindParam(':email_adm_editado', $_POST['email1']);
        
        $stmt3->execute();
  
        print_r('tmo ACTIVE editado con comentario');
            
            }
        
        
        
         if (!empty($_POST['email1']) && empty($_POST['comentario'])  )  
        {
            
            
        
        $sql6 = "INSERT INTO editado (email_adm, email_adm_editado,fecha_editado,operacion) VALUES ('$administrador',:email_adm_editado,NOW(),'editado')";
    $stmt6 = $conn->prepare($sql6);
      
       $stmt6->bindParam(':email_adm_editado', $_POST['email1']);
        
        $stmt6->execute();
  
        print_r('tmo ACTIVE editado sin comentario');
            
            }
        
        
        
        
        
        
        
        
        
       header("Location: /Turnos/manejaradministrador.php");
       
        print_r('tmo ACTIVE');

}else{
    
    echo "Insercion no exitosa";
    }
  
 

?>